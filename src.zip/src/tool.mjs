export function createId() {
    return `${Date.now()}${Math.random() * 100000}`
}